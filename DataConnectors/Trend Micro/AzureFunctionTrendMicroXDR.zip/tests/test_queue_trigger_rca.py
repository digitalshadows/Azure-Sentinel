import json
from unittest import TestCase
from unittest.mock import ANY, patch, MagicMock
import os
import importlib
from shared_code import configurations

from requests.models import HTTPError

MOCK_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4"
ENV = {
    "apiTokens": MOCK_TOKEN,
    "regionCode": "uae",
    "AzureWebJobsStorage": "fakeconnection",
    "workspaceId": "6a183caf-a148-4a43-845a-db6f4e645bfb",
    "workspaceKey": "m4qj7Y+sgW1hTi66m07/++fkGl38Dq46DwmDwOdx/vaWU86N5x8NicNmBeXXmgSbosTIfpL+AEuLigwQhidVPw==",
}
MOCK_CLP_ID = "8c840873-3145-4e5a-aede-021679ce23d8"
MOCK_TASK_ID = "3fa85f64-5717-4562-b3fc-2c963f66afa6"
MOCK_TASK_NAME = "WB-1-20191025-00001-PTE_RCA-9b034206"
MOCK_TARGET_GUID = "35FA11DA-A24E-40CF-8B56-BAF8828CC15E"
MOCK_WB_ID = "WB-2-20200214-0003"


class TestQueueTriggerRca(TestCase):
    rca_details = {}
    pwd = os.path.dirname(__file__)

    def setUp(self):
        with open(f"{self.pwd}/data/prca_result_source.json") as f:
            self.rca_details = json.load(f)['data']

        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.queue_trigger_rca = importlib.import_module('queue_trigger_rca')
        return super().setUp()

    @patch('queue_trigger_rca.utils.find_token_by_clp')
    @patch('queue_trigger_rca.get_rca_task_detail')
    @patch('queue_trigger_rca.LogAnalytics')
    def test_main_success(
        self, mock_log_analytics, mock_get_rca_task_detail, mock_find_token_by_clp
    ):
        rcaMsg = MagicMock()

        rcaMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "task_id": MOCK_TASK_ID,
            "workbench_id": MOCK_WB_ID,
            "task_name": MOCK_TASK_NAME,
            "target_guid": MOCK_TARGET_GUID,
            "target_info": {},
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_get_rca_task_detail.return_value = self.rca_details

        self.queue_trigger_rca.main(rcaMsg)

        mock_get_rca_task_detail.assert_called_with(
            MOCK_TOKEN, MOCK_TASK_ID, MOCK_TARGET_GUID
        )
        self.assertEqual(1, mock_log_analytics.call_count)

    @patch('queue_trigger_rca.utils.find_token_by_clp')
    @patch('queue_trigger_rca.get_rca_task_detail')
    @patch('queue_trigger_rca.LogAnalytics')
    def test_main_get_rca_task_detail_failed_throw_exception(
        self, mock_log_analytics, mock_get_rca_task_detail, mock_find_token_by_clp
    ):
        rcaMsg = MagicMock()

        rcaMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "task_id": MOCK_TASK_ID,
            "workbench_id": MOCK_WB_ID,
            "task_name": MOCK_TASK_NAME,
            "target_guid": MOCK_TARGET_GUID,
            "target_info": {},
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_get_rca_task_detail.side_effect = HTTPError()

        with self.assertRaises(HTTPError):
            self.queue_trigger_rca.main(rcaMsg)

        mock_log_analytics.assert_not_called()

    @patch('queue_trigger_rca.utils.find_token_by_clp')
    @patch('queue_trigger_rca.get_rca_task_detail')
    @patch('queue_trigger_rca.LogAnalytics')
    def test_main_unexpected_failed_throw_exception(
        self, mock_log_analytics, mock_get_rca_task_detail, mock_find_token_by_clp
    ):
        rcaMsg = MagicMock()

        rcaMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "task_id": MOCK_TASK_ID,
            "workbench_id": MOCK_WB_ID,
            "task_name": MOCK_TASK_NAME,
            "target_guid": MOCK_TARGET_GUID,
            "target_info": {},
        }

        mock_find_token_by_clp.side_effect = Exception()

        with self.assertRaises(Exception):
            self.queue_trigger_rca.main(rcaMsg)

        mock_get_rca_task_detail.assert_not_called()
        mock_log_analytics.assert_not_called()
